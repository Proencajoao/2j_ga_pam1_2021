import { Component } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {
  gasolina = null;
  alcool = null;
  resposta = '';

  combustiveis =[
    'gasolina.png',
    'alcool.png',
    "inicio.jpg"
  ]
  combustivel = "inicio.jpg"

  constructor() {}

  calcular(indice: number): void{
    
    
    let g = this.gasolina * 0.7;
    let a = this.alcool * 0.7;
    
    if(a < g){
      this.resposta = "Álcool é o melhor combustivel";
      this.combustivel = this.combustiveis [1];
    }else if(a > g){
      this.resposta = "Gasolina é a melhor combustivel";
      this.combustivel = this.combustiveis [0];
    }else{
      this.resposta = "Tanto faz o combustível";
      this.combustivel = this.combustiveis [2];
    }
    
  }
}
